# Architecture

UI (Jetpack Compose)
        |
ViewModels / State
        |
+----------------------+----------------------+
| Identity             | Chat / File / Call   |
| SQR-ID + keypair     | encrypted envelopes  |
+----------------------+----------------------+
        |
LAN Transport (TCP/WebSocket/HTTP)
        |
NSD/mDNS discovery
        |
Wi‑Fi / Wi‑Fi Direct

## Suggested envelope
{
  version,
  messageId,
  senderId,
  recipientId,
  timestamp,
  type: TEXT | AUDIO | FILE | CALL_SIGNAL,
  nonce,
  ciphertext,
  sha256
}

The transport must treat the payload as opaque ciphertext.
