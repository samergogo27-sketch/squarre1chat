package com.squirrelchat.app.core

import android.content.Intent
import androidx.activity.ComponentActivity

/**
 * File picker deliberately uses ACTION_OPEN_DOCUMENT with */*.
 * This means APK/EXE/ISO/ZIP/PDF/video/etc. are not blocked by extension.
 * The transport layer should stream bytes in chunks and encrypt each transfer.
 */
object FileShare {
    private const val REQUEST = 9001

    fun pickAnyFile() {
        // This method is a hook; ActivityResultContracts.OpenDocument should be
        // used in the real UI. MIME type */* keeps the picker unrestricted.
    }

    fun intent(): Intent =
        Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addCategory(Intent.CATEGORY_OPENABLE)
        }
}
