package com.squirrelchat.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.*
import com.squirrelchat.app.ui.SquirrelTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SquirrelTheme { SquirrelApp() } }
    }
}

@Composable
fun SquirrelApp() {
    var loggedIn by remember { mutableStateOf(false) }
    if (!loggedIn) {
        LoginScreen(onLogin = { loggedIn = true })
    } else {
        MainShell()
    }
}

@Composable
fun LoginScreen(onLogin: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var generatedId by remember { mutableStateOf("SQR-" + (1000..9999).random()) }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🐿️", fontSize = 82.sp)
        Text("Squirrel Chat", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
        Text("تواصل بسيط عبر Wi‑Fi", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(22.dp))

        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(),
            label = { Text("اسم المستخدم") }, singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(),
            label = { Text("كلمة المرور") }, singleLine = true)

        Spacer(Modifier.height(10.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Text("رقمك الداخلي", fontWeight = FontWeight.Bold)
                Text(generatedId, fontSize = 22.sp, color = MaterialTheme.colorScheme.primary)
                Text("ليس رقم هاتف ولا يحتاج كود دولة.", fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(18.dp))
        Button(
            onClick = onLogin,
            enabled = name.trim().isNotEmpty() && password.length >= 4,
            Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(18.dp)
        ) { Text("إنشاء الحساب والدخول") }
    }
}

@Composable
fun MainShell() {
    val nav = rememberNavController()
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(true, { nav.navigate("home") }, icon = { Icon(Icons.Default.Chat, null) }, label = { Text("الدردشة") })
                NavigationBarItem(false, { nav.navigate("contacts") }, icon = { Icon(Icons.Default.People, null) }, label = { Text("الأصدقاء") })
                NavigationBarItem(false, { nav.navigate("profile") }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("حسابي") })
            }
        }
    ) { pad ->
        NavHost(nav, "home", Modifier.padding(pad)) {
            composable("home") { HomeScreen { nav.navigate("chat/$it") } }
            composable("contacts") { ContactsScreen { nav.navigate("chat/$it") } }
            composable("profile") { ProfileScreen() }
            composable("chat/{id}") { back -> ChatScreen(back.arguments?.getString("id") ?: "صديق") }
        }
    }
}

data class ChatPreview(val id: String, val name: String, val last: String, val online: Boolean)

@Composable
fun HomeScreen(openChat: (String) -> Unit) {
    var search by remember { mutableStateOf("") }
    val chats = listOf(
        ChatPreview("SQR-4821", "سنجاب", "أهلاً! 👋", true),
        ChatPreview("SQR-7710", "ليان", "تم إرسال ملف ZIP", false)
    )
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Squirrel Chat", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Text("بدون رقم هاتف • عبر Wi‑Fi", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(),
            placeholder = { Text("اسم المستخدم أو SQR-ID") },
            leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true,
            shape = RoundedCornerShape(18.dp))
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(chats.filter { search.isBlank() || it.name.contains(search, true) || it.id.contains(search, true) }) {
                Card(onClick = { openChat(it.id) }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        SquirrelAvatar(it.name, it.online)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(it.name, fontWeight = FontWeight.Bold)
                            Text(it.last, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(it.id, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
fun ContactsScreen(openChat: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("الأصدقاء", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Button(onClick = {}, Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Wifi, null); Spacer(Modifier.width(8.dp))
            Text("البحث عن مستخدمين على Wi‑Fi")
        }
        Spacer(Modifier.height(12.dp))
        listOf("SQR-4821" to "سنجاب", "SQR-7710" to "ليان").forEach { (id, name) ->
            ListItem(
                headlineContent = { Text(name) },
                supportingContent = { Text(id) },
                leadingContent = { SquirrelAvatar(name, true) },
                trailingContent = { IconButton({ openChat(id) }) { Icon(Icons.Default.Chat, null) } }
            )
        }
    }
}

@Composable
fun ChatScreen(id: String) {
    var text by remember { mutableStateOf("") }
    var recording by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        // Production: stream selected URIs through the encrypted LAN transport.
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            SquirrelAvatar(id, true)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(id, fontWeight = FontWeight.Bold)
                Text("على الشبكة المحلية", fontSize = 12.sp)
            }
            IconButton({}) { Icon(Icons.Default.Call, null) }
            IconButton({}) { Icon(Icons.Default.Videocam, null) }
        }
        HorizontalDivider()
        LazyColumn(Modifier.weight(1f).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { MessageBubble("مرحباً! 🐿️", false) }
            item { MessageBubble("يمكنك إرسال APK / EXE / ISO / ZIP وأي ملف.", true) }
        }
        if (recording) {
            AssistChip(onClick = { recording = false }, label = { Text("جاري التسجيل…") },
                leadingIcon = { Icon(Icons.Default.Mic, null) })
        }
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({
                picker.launch(arrayOf("*/*"))
            }) { Icon(Icons.Default.AttachFile, "إرسال ملف") }
            IconButton({ recording = !recording }) { Icon(Icons.Default.Mic, "رسالة صوتية") }
            OutlinedTextField(text, { text = it }, Modifier.weight(1f),
                placeholder = { Text("اكتب رسالة…") }, singleLine = true,
                shape = RoundedCornerShape(22.dp))
            IconButton({ text = "" }) { Icon(Icons.Default.Send, "إرسال") }
        }
    }
}

@Composable
fun MessageBubble(text: String, mine: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Surface(shape = RoundedCornerShape(18.dp), tonalElevation = 2.dp) {
            Text(text, Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
        }
    }
}

@Composable
fun ProfileScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        SquirrelAvatar("أنا", true, 100.dp)
        Spacer(Modifier.height(12.dp))
        Text("حسابي", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("SQR-ID: SQR-4821", color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(20.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("🐿️ حساب بدون هاتف", fontWeight = FontWeight.Bold)
                Text("اسم مستخدم + كلمة مرور + رقم داخلي عشوائي.")
            }
        }
    }
}

@Composable
fun SquirrelAvatar(name: String, online: Boolean, size: androidx.compose.ui.unit.Dp = 56.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center) {
        Text("🐿️", fontSize = (size.value / 2).sp)
        if (online) Box(Modifier.size(12.dp).clip(CircleShape).background(Color(0xFF31A24C)).align(Alignment.BottomEnd))
    }
}
