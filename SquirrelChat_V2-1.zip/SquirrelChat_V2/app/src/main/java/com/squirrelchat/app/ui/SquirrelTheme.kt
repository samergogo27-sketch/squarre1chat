package com.squirrelchat.app.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SquirrelLight = lightColorScheme(
    primary = Color(0xFF9A5B2E),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDEC7),
    secondary = Color(0xFF6D5A4B),
    background = Color(0xFFFFF8EF),
    surface = Color(0xFFFFFBF7)
)

@Composable
fun SquirrelTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = SquirrelLight, content = content)
}
