package com.squirrelchat.app.core

/**
 * WebRTC boundary.
 *
 * Signaling:
 *   1) encrypted WebSocket/HTTP on the same LAN
 *   2) exchange SDP offer/answer
 *   3) exchange ICE candidates
 * Media:
 *   WebRTC SRTP handles audio/video encryption in transit.
 *
 * For a production build, add a maintained Android WebRTC AAR and implement
 * this interface. The rest of the app does not need to know WebRTC details.
 */
interface CallEngine {
    fun startAudioCall(peerId: String)
    fun startVideoCall(peerId: String)
    fun acceptCall(callId: String)
    fun hangUp(callId: String)
}
