package com.squirrelchat.app.core

import android.util.Base64
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Security building block.
 * Production: use a per-conversation key agreement (X25519) and rotate keys.
 * Never store raw passwords; derive a verifier with Argon2id/scrypt in production.
 */
object CryptoBox {
    fun newIdentityKeyPair() =
        KeyPairGenerator.getInstance("EC").apply { initialize(256) }.generateKeyPair()

    fun randomConversationKey(): SecretKey {
        val gen = KeyGenerator.getInstance("AES")
        gen.init(256)
        return gen.generateKey()
    }

    fun encrypt(bytes: ByteArray, key: SecretKey): ByteArray {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        val body = cipher.doFinal(bytes)
        return iv + body
    }

    fun decrypt(packet: ByteArray, key: SecretKey): ByteArray {
        require(packet.size > 12)
        val iv = packet.copyOfRange(0, 12)
        val body = packet.copyOfRange(12, packet.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return cipher.doFinal(body)
    }

    fun sha256(text: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(text.toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun b64(bytes: ByteArray) = Base64.encodeToString(bytes, Base64.NO_WRAP)
}
