package com.squirrelchat.app.core

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo

/**
 * LAN discovery using Android NSD/mDNS.
 * Each device advertises a short-lived service containing only a random SQR-ID
 * and a public identity key. No phone number is used.
 */
class PeerDiscovery(private val context: Context) {
    private val nsd = context.getSystemService(NsdManager::class.java)
    private val serviceType = "_squirrel._tcp."

    fun advertise(sqrId: String, port: Int) {
        val info = NsdServiceInfo().apply {
            serviceName = "Squirrel-$sqrId"
            serviceType = serviceType
            this.port = port
        }
        nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(serviceInfo: NsdServiceInfo) {}
            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
            override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) {}
            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
        })
    }

    fun discover(onPeer: (NsdServiceInfo) -> Unit) {
        nsd.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD,
            object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(regType: String) {}
                override fun onServiceFound(info: NsdServiceInfo) {
                    nsd.resolveService(info, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
                        override fun onServiceResolved(serviceInfo: NsdServiceInfo) { onPeer(serviceInfo) }
                    })
                }
                override fun onServiceLost(serviceInfo: NsdServiceInfo) {}
                override fun onDiscoveryStopped(serviceType: String) {}
                override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
                override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
            })
    }
}
